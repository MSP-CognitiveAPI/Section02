﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Linq;
using System.Windows.Forms;
using YoutubeExtractor;
using System.Net;
using System.Net.Http;
using JDP;
using MediaToolkit.Model;
using MediaToolkit.Options;
using MediaToolkit;
using NAudio.Wave;
using WMPLib;
using Microsoft.CognitiveServices.SpeechRecognition;
using System.IO;
using System.Text;
using System.Web;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;

namespace translator
{


    public partial class Form1 : Form
    {
        Process prcFFMPEG = new Process();
        private string itemSelected;
        private string selectedIndex;
        public string FileDir;
        private DataRecognitionClient m_dataClient;
        private SpeechRecognitionMode m_recoMode = SpeechRecognitionMode.LongDictation;
        public string[] DefaultLocale = { "en-US", "ja-JP", "ko-KR", "zh-CN" };
        public string[] resolution = { "240", "360", "480" };
        private string primaryKey2 = "4154a6488c024226a13ecab7f3b3207f";
        private const string Translate_SubscriptionKey = "61e621efd253434f8c5462e4de4f1249";

        private void initalize()
        {
            m_dataClient = SpeechRecognitionServiceFactory.CreateDataClient(m_recoMode, itemSelected, primaryKey2);

            // Event handlers for speech recognition results
            m_dataClient.OnResponseReceived += this.OnResponseReceivedHandler;
            m_dataClient.OnPartialResponseReceived += this.OnPartialResponseReceivedHandler;
            m_dataClient.OnConversationError += this.OnConversationErrorHandler;

            Language.Items.AddRange(DefaultLocale);
            Language.SelectedIndex = 0;

            selectResolution.Items.AddRange(resolution);
            selectResolution.SelectedIndex = 0;
        }



        public Form1()
        {
            InitializeComponent();
            initalize();
        }




        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void WriteLine()
        {
            this.WriteLine(string.Empty);
        }

        private void WriteLine(string format, params object[] args)
        {
            var formattedStr = string.Format(format, args);
            Trace.WriteLine(formattedStr);
            System.Console.WriteLine(formattedStr);
        }

        private void OnConversationErrorHandler(object sender, SpeechErrorEventArgs e)
        {
            this.WriteLine("********* Error Detected *********");
            this.WriteLine("{0}", e.SpeechErrorCode.ToString());
            this.WriteLine("{0}", e.SpeechErrorText);
            this.WriteLine();
        }

        private void OnPartialResponseReceivedHandler(object sender, PartialSpeechResponseEventArgs e)
        {
            this.WriteLine("********* Partial Result *********");
            this.WriteLine("{0}", e.PartialResult);
            this.WriteLine();
        }

        private void OnResponseReceivedHandler(object sender, SpeechResponseEventArgs e)
        {
            bool isFinalDicationMessage = m_recoMode == SpeechRecognitionMode.LongDictation &&
                                        (e.PhraseResponse.RecognitionStatus == RecognitionStatus.EndOfDictation ||
                                         e.PhraseResponse.RecognitionStatus == RecognitionStatus.DictationEndSilenceTimeout);

            if (!isFinalDicationMessage)
            {
                this.WriteLine("********* Final NBEST Results *********");

                for (int i = 0; i < e.PhraseResponse.Results.Length; i++)
                {
                    this.WriteLine("[{0}] Confidence={1} Text=\"{2}\"",
                                   i, e.PhraseResponse.Results[i].Confidence,
                                   e.PhraseResponse.Results[i].DisplayText);


                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(FileDir, true))
                    {
                        file.WriteLine(e.PhraseResponse.Results[i].DisplayText);
                    }
                }
                this.WriteLine();
            }
        }

        void OnIntentHandler(object sender, SpeechIntentEventArgs e)
        {
            this.WriteLine("********* Final Intent *********");
            this.WriteLine("{0}", e.Payload);
            this.WriteLine();
        }


        private void SendAudioHelper(string wavFileName)
        {
            using (FileStream fileStream = new FileStream(wavFileName, FileMode.Open, FileAccess.Read))
            {
                int bytesRead = 0;
                byte[] buffer = new byte[1024];

                try
                {
                    do
                    {
                        // Get more Audio data to send into byte buffer.
                        bytesRead = fileStream.Read(buffer, 0, buffer.Length);

                        // Send of audio data to service. 
                        this.m_dataClient.SendAudio(buffer, bytesRead);
                    }
                    while (bytesRead > 0);
                }
                finally
                {
                    this.m_dataClient.EndAudio();
                }
            }
        }


        private void Language_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Language.SelectedIndex >= 0)
            {
                itemSelected = Language.SelectedItem as string;
            }
        }

        private void selectResolution_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (selectResolution.SelectedIndex >= 0)
            {
                selectedIndex = selectResolution.SelectedItem as string;
            }
            // MessageBox.Show(selectedIndex.ToString());
        }

        private void Video_download_Click(object sender, EventArgs e)
        {
            DownloadBar.Minimum = 0;
            DownloadBar.Maximum = 100;

            IEnumerable<VideoInfo> videos = DownloadUrlResolver.GetDownloadUrls(txtURL.Text);
            VideoInfo video = videos.First(p => p.VideoType == VideoType.Mp4 && p.Resolution == Convert.ToInt32(selectedIndex));
            if (video.RequiresDecryption)
                DownloadUrlResolver.DecryptDownloadUrl(video);
            VideoDownloader downloader = new VideoDownloader(video, Path.Combine(Application.StartupPath + "\\", video.Title + video.VideoExtension));
            downloader.DownloadProgressChanged += DownloadBar_DownloadProgressChanged;
            Thread thread = new Thread(() => { downloader.Execute(); }) { IsBackground = true };
            thread.Start();

        }

        private void DownloadBar_DownloadProgressChanged(object sender, ProgressEventArgs e)
        {
            Invoke(new MethodInvoker(delegate ()
            {
                DownloadBar.Value = (int)e.ProgressPercentage;
                progressText.Text = $"{string.Format("{0:0.##}", e.ProgressPercentage)}%";
                DownloadBar.Update();
            }));
        }

        private void MakeMp3_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "MP4 File (*.mp4)|*.mp4;";
            if (open.ShowDialog() != DialogResult.OK) return;

            var inputFile = new MediaFile { Filename = open.FileName };
            var outputFile = new MediaFile { Filename = @"C:\Users\송명진\Desktop\save.flv" };

            var player = new WindowsMediaPlayer();
            var clip = player.newMedia(open.FileName);

            var conversionOptions = new ConversionOptions
            {
                MaxVideoDuration = TimeSpan.FromSeconds(clip.duration), //몇초까지 설정할 것인지 
                VideoAspectRatio = VideoAspectRatio.R16_9,
                VideoSize = VideoSize.Hd1080,
                AudioSampleRate = AudioSampleRate.Hz44100
            };

            using (var engine = new Engine())
            {
                engine.Convert(inputFile, outputFile, conversionOptions);
            }
            MessageBox.Show("파일 전환이 완료되었습니다.");



        }

        private void MakeWave_Click(object sender, EventArgs e)
        {
            
             MessageBox.Show("변환할 파일을 불러주세요!");

             OpenFileDialog open = new OpenFileDialog();
             open.Filter = "FLV File (*.flv)|*.flv;";
             if (open.ShowDialog() != DialogResult.OK) return;

             FLVFile test = new FLVFile(open.FileName);
             test.ExtractStreams(true, false, false, null);

             MessageBox.Show("mp3 convert is done");
             

        }

        private void Make_Wave_Click(object sender, EventArgs e)
        {
          

            MessageBox.Show("변환할 파일을 불러주세요!");
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "MP3 File (*.mp3)|*.mp3;";
            if (open.ShowDialog() != DialogResult.OK) return;

            MessageBox.Show("저장할 파일경로를 지정해주세요!");
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "WAV File (*.wav)|*.wav;";
            if (save.ShowDialog() != DialogResult.OK) return;

           // FLVFile 
            using (Mp3FileReader mp3 = new Mp3FileReader(open.FileName))
            {
                using (WaveStream pcm = WaveFormatConversionStream.CreatePcmStream(mp3))
                {
                    WaveFileWriter.CreateWaveFile(save.FileName, pcm);
                }
            }


            MessageBox.Show("The work is done");
        }

        private void MakeScript_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "WAV File (*.wav)|*.wav;";
            if (open.ShowDialog() != DialogResult.OK) return;

            MessageBox.Show("대본을 저장할 장소를 정해주세요.");

            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Text File | *.txt";
            if (save.ShowDialog() != DialogResult.OK) return;

            FileDir = save.FileName;



            MessageBox.Show("대본을 만들기 시작합니다!");

            this.SendAudioHelper(open.FileName);

            //CreateDataRecoClient();
            MessageBox.Show("파일 전환이 완료되었습니다.");

        }

        private void CreateDataRecoClient()
        {
            m_dataClient = SpeechRecognitionServiceFactory.CreateDataClient(m_recoMode, itemSelected, primaryKey2);

            // Event handlers for speech recognition results
            m_dataClient.OnResponseReceived += this.OnResponseReceivedHandler;
            m_dataClient.OnPartialResponseReceived += this.OnPartialResponseReceivedHandler;
            m_dataClient.OnConversationError += this.OnConversationErrorHandler;

        }

        private void TRANSLATOR_Click(object sender, EventArgs e)
        {
            AdmAccessToken admToken;
            string headerValue;
            AdmAuthentication admAuth = new AdmAuthentication("reki318", "0LZCC/QenWjOVb7vuBdXJ5yX5jI/69uQGnAVzF2VYvw=");

            try
            {
                admToken = admAuth.GetAccessToken();
                headerValue = "Bearer " + admToken.access_token;
                TransformTextMethod(headerValue);
            }
            catch (WebException e1)
            {
                ProcessWebException(e1);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ProcessWebException(WebException e)
        {
            Console.WriteLine("{0}", e.ToString());
            // Obtain detailed error information
            string strResponse = string.Empty;
            using (HttpWebResponse response = (HttpWebResponse)e.Response)
            {
                using (Stream responseStream = response.GetResponseStream())
                {
                    using (StreamReader sr = new StreamReader(responseStream, System.Text.Encoding.ASCII))
                    {
                        strResponse = sr.ReadToEnd();
                    }
                }
            }
            Console.WriteLine("Http status code={0}, error message={1}", e.Status, strResponse);
        }

    private static void TransformTextMethod(string authToken)
        {
            string text = System.IO.File.ReadAllText(@"C:\Users\송명진\Desktop\대본.txt");
            string from = "en";
            string to = "ko";

            string uri = "http://api.microsofttranslator.com/v2/Http.svc/Translate?text=" + System.Web.HttpUtility.UrlEncode(text) + "&from=" + from + "&to=" + to;

            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(uri);
            httpWebRequest.Headers.Add("Authorization", authToken);

            WebResponse response = null;
            try
            {
                response = httpWebRequest.GetResponse();
                using (Stream stream = response.GetResponseStream())
                {
                    System.Runtime.Serialization.DataContractSerializer dcs = new System.Runtime.Serialization.DataContractSerializer(Type.GetType("System.String"));
                    string translation = (string)dcs.ReadObject(stream);
                    Console.WriteLine("Translation for source text '{0}' from {1} to {2} is", text, "en", "de");
                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\송명진\Desktop\대본_번역.txt", true))
                    {
                        file.WriteLine(translation);
                    }
                }
            }
            catch(HttpRequestException e)
            {
                Console.WriteLine(e);
            }


            MessageBox.Show("변환이 완료되었습니다!");
        }

        public class TransformTextResponse
        {

            public int ec { get; set; }

            public string em { get; set; }

            public string sentence { get; set; }
        }

        public class AdmAccessToken
        {

            public string access_token { get; set; }

            public string token_type { get; set; }

            public string expires_in { get; set; }

            public string scope { get; set; }
        }
        public class AdmAuthentication
        {
            public static readonly string DatamarketAccessUri = "https://datamarket.accesscontrol.windows.net/v2/OAuth2-13";
            private string clientId;
            private string clientSecret;
            private string request;
            private AdmAccessToken token;
            private System.Threading.Timer accessTokenRenewer;
            //Access token expires every 10 minutes. Renew it every 9 minutes only.
            private const int RefreshTokenDuration = 9;
            public AdmAuthentication(string clientId, string clientSecret)
            {
                this.clientId = clientId;
                this.clientSecret = clientSecret;
                //If clientid or client secret has special characters, encode before sending request
                this.request = string.Format("grant_type=client_credentials&client_id={0}&client_secret={1}&scope=http://api.microsofttranslator.com", HttpUtility.UrlEncode(clientId), HttpUtility.UrlEncode(clientSecret));
                this.token = HttpPost(DatamarketAccessUri, this.request);
                //renew the token every specfied minutes
                accessTokenRenewer = new System.Threading.Timer(new TimerCallback(OnTokenExpiredCallback), this, TimeSpan.FromMinutes(RefreshTokenDuration), TimeSpan.FromMilliseconds(-1));
            }
            public AdmAccessToken GetAccessToken()
            {
                return this.token;
            }
            private void RenewAccessToken()
            {
                AdmAccessToken newAccessToken = HttpPost(DatamarketAccessUri, this.request);
                this.token = newAccessToken;
                Console.WriteLine(string.Format("Renewed token for user: {0} is: {1}", this.clientId, this.token.access_token));
            }
            private void OnTokenExpiredCallback(object stateInfo)
            {
                try
                {
                    RenewAccessToken();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(string.Format("Failed renewing access token. Details: {0}", ex.Message));
                }
                finally
                {
                    try
                    {
                        accessTokenRenewer.Change(TimeSpan.FromMinutes(RefreshTokenDuration), TimeSpan.FromMilliseconds(-1));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(string.Format("Failed to reschedule the timer to renew access token. Details: {0}", ex.Message));
                    }
                }
            }
            private AdmAccessToken HttpPost(string DatamarketAccessUri, string requestDetails)
            {
                //Prepare OAuth request 
                WebRequest webRequest = WebRequest.Create(DatamarketAccessUri);
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.Method = "POST";
                byte[] bytes = Encoding.ASCII.GetBytes(requestDetails);
                webRequest.ContentLength = bytes.Length;
                using (Stream outputStream = webRequest.GetRequestStream())
                {
                    outputStream.Write(bytes, 0, bytes.Length);
                }
                using (WebResponse webResponse = webRequest.GetResponse())
                {
                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(AdmAccessToken));
                    //Get deserialized object from JSON stream
                    AdmAccessToken token = (AdmAccessToken)serializer.ReadObject(webResponse.GetResponseStream());
                    return token;
                }
            }


        }
    }
}
