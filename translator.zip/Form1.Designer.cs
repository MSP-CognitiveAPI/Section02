﻿namespace translator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Language = new System.Windows.Forms.ComboBox();
            this.MakeScript = new System.Windows.Forms.Button();
            this.TRANSLATOR = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DownloadBar = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.txtURL = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.selectResolution = new System.Windows.Forms.ComboBox();
            this.Video_download = new System.Windows.Forms.Button();
            this.MakeFLV = new System.Windows.Forms.Button();
            this.ConvertToMP3 = new System.Windows.Forms.Button();
            this.progressText = new System.Windows.Forms.Label();
            this.Make_Wave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Language
            // 
            this.Language.FormattingEnabled = true;
            this.Language.Location = new System.Drawing.Point(15, 360);
            this.Language.Name = "Language";
            this.Language.Size = new System.Drawing.Size(188, 26);
            this.Language.TabIndex = 0;
            this.Language.SelectedIndexChanged += new System.EventHandler(this.Language_SelectedIndexChanged);
            // 
            // MakeScript
            // 
            this.MakeScript.Location = new System.Drawing.Point(15, 406);
            this.MakeScript.Name = "MakeScript";
            this.MakeScript.Size = new System.Drawing.Size(188, 53);
            this.MakeScript.TabIndex = 1;
            this.MakeScript.Text = "MAKE SCRIPT";
            this.MakeScript.UseVisualStyleBackColor = true;
            this.MakeScript.Click += new System.EventHandler(this.MakeScript_Click);
            // 
            // TRANSLATOR
            // 
            this.TRANSLATOR.Location = new System.Drawing.Point(209, 406);
            this.TRANSLATOR.Name = "TRANSLATOR";
            this.TRANSLATOR.Size = new System.Drawing.Size(162, 53);
            this.TRANSLATOR.TabIndex = 2;
            this.TRANSLATOR.Text = "TRANSLATOR";
            this.TRANSLATOR.UseVisualStyleBackColor = true;
            this.TRANSLATOR.Click += new System.EventHandler(this.TRANSLATOR_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(369, 18);
            this.label1.TabIndex = 3;
            this.label1.Text = "Section 1 Extract Youtube & Make WAVE FILE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "RESOLUTION :";
            // 
            // DownloadBar
            // 
            this.DownloadBar.Location = new System.Drawing.Point(15, 240);
            this.DownloadBar.Name = "DownloadBar";
            this.DownloadBar.Size = new System.Drawing.Size(487, 36);
            this.DownloadBar.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 318);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(271, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Section 2 Make Script & Translate";
            // 
            // txtURL
            // 
            this.txtURL.Location = new System.Drawing.Point(98, 64);
            this.txtURL.Name = "txtURL";
            this.txtURL.Size = new System.Drawing.Size(404, 28);
            this.txtURL.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "URL :";
            // 
            // selectResolution
            // 
            this.selectResolution.FormattingEnabled = true;
            this.selectResolution.Location = new System.Drawing.Point(155, 111);
            this.selectResolution.Name = "selectResolution";
            this.selectResolution.Size = new System.Drawing.Size(347, 26);
            this.selectResolution.TabIndex = 9;
            this.selectResolution.SelectedIndexChanged += new System.EventHandler(this.selectResolution_SelectedIndexChanged);
            // 
            // Video_download
            // 
            this.Video_download.Location = new System.Drawing.Point(15, 160);
            this.Video_download.Name = "Video_download";
            this.Video_download.Size = new System.Drawing.Size(133, 47);
            this.Video_download.TabIndex = 10;
            this.Video_download.Text = "Download";
            this.Video_download.UseVisualStyleBackColor = true;
            this.Video_download.Click += new System.EventHandler(this.Video_download_Click);
            // 
            // MakeFLV
            // 
            this.MakeFLV.Location = new System.Drawing.Point(151, 160);
            this.MakeFLV.Name = "MakeFLV";
            this.MakeFLV.Size = new System.Drawing.Size(115, 47);
            this.MakeFLV.TabIndex = 11;
            this.MakeFLV.Text = "MakeFLV";
            this.MakeFLV.UseVisualStyleBackColor = true;
            this.MakeFLV.Click += new System.EventHandler(this.MakeMp3_Click);
            // 
            // ConvertToMP3
            // 
            this.ConvertToMP3.Location = new System.Drawing.Point(268, 160);
            this.ConvertToMP3.Name = "ConvertToMP3";
            this.ConvertToMP3.Size = new System.Drawing.Size(116, 47);
            this.ConvertToMP3.TabIndex = 12;
            this.ConvertToMP3.Text = "Convert";
            this.ConvertToMP3.UseVisualStyleBackColor = true;
            this.ConvertToMP3.Click += new System.EventHandler(this.MakeWave_Click);
            // 
            // progressText
            // 
            this.progressText.AutoSize = true;
            this.progressText.Location = new System.Drawing.Point(409, 291);
            this.progressText.Name = "progressText";
            this.progressText.Size = new System.Drawing.Size(112, 18);
            this.progressText.TabIndex = 13;
            this.progressText.Text = "Percentage :";
            // 
            // Make_Wave
            // 
            this.Make_Wave.Location = new System.Drawing.Point(387, 160);
            this.Make_Wave.Name = "Make_Wave";
            this.Make_Wave.Size = new System.Drawing.Size(115, 47);
            this.Make_Wave.TabIndex = 14;
            this.Make_Wave.Text = "MakeWAV";
            this.Make_Wave.UseVisualStyleBackColor = true;
            this.Make_Wave.Click += new System.EventHandler(this.Make_Wave_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 523);
            this.Controls.Add(this.Make_Wave);
            this.Controls.Add(this.progressText);
            this.Controls.Add(this.ConvertToMP3);
            this.Controls.Add(this.MakeFLV);
            this.Controls.Add(this.Video_download);
            this.Controls.Add(this.selectResolution);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtURL);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.DownloadBar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TRANSLATOR);
            this.Controls.Add(this.MakeScript);
            this.Controls.Add(this.Language);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox Language;
        private System.Windows.Forms.Button MakeScript;
        private System.Windows.Forms.Button TRANSLATOR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar DownloadBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtURL;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox selectResolution;
        private System.Windows.Forms.Button Video_download;
        private System.Windows.Forms.Button MakeFLV;
        private System.Windows.Forms.Button ConvertToMP3;
        private System.Windows.Forms.Label progressText;
        private System.Windows.Forms.Button Make_Wave;
    }
}

